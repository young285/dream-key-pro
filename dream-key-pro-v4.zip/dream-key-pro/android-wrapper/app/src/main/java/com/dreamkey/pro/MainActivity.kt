package com.dreamkey.pro

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val web = WebView(this)
        web.webViewClient = WebViewClient()
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        // 아래 주소를 실제 HTTPS 배포 주소로 변경하세요.
        web.loadUrl("https://YOUR-DOMAIN.example/dream-key-pro/")
        setContentView(web)
    }
}
