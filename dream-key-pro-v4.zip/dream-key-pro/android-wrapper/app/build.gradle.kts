plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.dreamkey.pro"; compileSdk=35
    defaultConfig { applicationId="com.dreamkey.pro"; minSdk=24; targetSdk=35; versionCode=3; versionName="3.0" }
}
dependencies { implementation("androidx.appcompat:appcompat:1.7.0"); implementation("androidx.webkit:webkit:1.12.1") }
