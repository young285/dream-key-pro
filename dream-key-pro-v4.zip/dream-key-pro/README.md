# 드림 자동차키 Pro v3

## 포함 기능
- 매출·순이익·일평균 차량·차량당 평균 마진
- 미수금 관리와 입금 완료 처리
- 작업 등록·수정·삭제·검색·월/작업/결제 필터
- 재고 등록·수정·자동 차감·부족 알림
- CSV 내보내기, JSON 백업·복원
- 최근 6개월 매출 그래프
- PWA 홈 화면 설치 및 오프라인 실행
- Google Sheets 백업/복원 연동
- Telegram 작업·입금·재고 부족 알림
- VIN 조회 주소 연결
- Android WebView 포장용 소스 포함

## 실행 방법
웹서버에 폴더 전체를 올려야 앱 설치와 오프라인 기능이 정상 작동합니다. `index.html` 파일을 단독으로 열면 기본 기록 기능은 되지만 PWA 설치는 제한될 수 있습니다.

간단 테스트:
```bash
python -m http.server 8080
```
브라우저에서 `http://localhost:8080` 접속.

## Google Sheets
`integrations/google-apps-script.gs`를 새 Google 스프레드시트의 Apps Script에 붙여넣고 웹 앱으로 배포한 뒤, 앱의 설정 탭에 배포 URL을 입력합니다.

## Telegram
BotFather에서 봇 토큰을 만들고 Chat ID를 확인한 뒤 설정 탭에 입력합니다. 토큰이 브라우저 저장소에 저장되므로 공용 기기에서는 사용하지 마세요.

## Android APK
`android-wrapper`는 Android Studio에서 열 수 있는 최소 WebView 포장 프로젝트입니다. 실제 배포용 APK는 서버 주소를 `MainActivity.kt`에 넣은 뒤 Android Studio에서 서명 빌드해야 합니다.

## v4 변경사항
- 작업 등록 시 부가세 포함/별도/해당 없음 선택
- 공급가액, 부가세, 최종금액 자동 계산
- 작업 내역과 CSV에 부가세 구분 및 금액 표시
- 기존 데이터는 부가세 미지정으로 안전하게 유지
