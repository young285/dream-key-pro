/**
 * 드림 자동차키 Pro - Google Apps Script 저장소
 * 1) 새 Google 스프레드시트에서 확장 프로그램 > Apps Script
 * 2) 이 코드를 붙여넣고 저장
 * 3) 배포 > 새 배포 > 웹 앱
 * 4) 실행 사용자: 나 / 액세스: 본인 또는 필요한 범위
 * 5) 배포 URL을 앱 설정에 입력
 */
const SHEET_NAME = 'DreamKeyData';

function doPost(e) {
  try {
    const req = JSON.parse(e.postData.contents || '{}');
    if (req.action === 'ping') return json({ok:true, message:'pong'});
    const sheet = getSheet_();
    if (req.action === 'save') {
      const data = JSON.stringify(req.data || {});
      sheet.getRange('A1').setValue('updatedAt');
      sheet.getRange('B1').setValue(new Date());
      sheet.getRange('A2').setValue('json');
      sheet.getRange('B2').setValue(data);
      return json({ok:true});
    }
    if (req.action === 'load') {
      const raw = sheet.getRange('B2').getValue();
      return json({ok:true, data: raw ? JSON.parse(raw) : null});
    }
    return json({ok:false, error:'unknown action'});
  } catch (err) {
    return json({ok:false, error:String(err)});
  }
}

function doGet() { return json({ok:true, app:'Dream Key Pro'}); }
function getSheet_(){
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  return ss.getSheetByName(SHEET_NAME) || ss.insertSheet(SHEET_NAME);
}
function json(obj){
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
